﻿#pragma once

#include "Core/CoreTypes.h"
#include "Render/Common/RenderTypes.h"

#include "Render/Resource/Buffer.h"

#include "Render/Mesh/MeshManager.h"

class UStaticMesh;

/*
	Mesh Manager에서 넘겨 받은 MeshData를 바탕으로 MeshBuffer를 생성하고 소유합니다.
*/

class FMeshBufferManager
{
private:
	ID3D11Device* Device = nullptr;
	TMap<EPrimitiveType, FMeshBuffer> MeshBufferMap;
	TMap<const UStaticMesh*, FMeshBuffer> StaticMeshBufferMap;
	TMap<const UStaticMesh*, FMeshBuffer> PerformanceMeshBufferMap;

public:

private:

public:
	void Create(ID3D11Device* InDevice);
	void Release();

	FMeshBuffer& GetMeshBuffer(EPrimitiveType InPrimitiveType);
	FMeshBuffer* GetStaticMeshBuffer(const UStaticMesh* StaticMeshAsset);
	FMeshBuffer* GetPerformanceMeshBuffer(const UStaticMesh* StaticMeshAsset);
};